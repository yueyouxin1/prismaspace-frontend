<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import { IconEdit, IconPlus, IconSearch, IconTrash } from '@tabler/icons-vue'
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuTrigger,
} from '@prismaspace/ui-shadcn/components/ui/context-menu'
import type { TenantTableContextAction } from '../types/tenantdb-ide'

const props = defineProps<{
  tableUuid: string
}>()

const emit = defineEmits<{
  (event: 'action', payload: { tableUuid: string; action: TenantTableContextAction }): void
}>()
const { t } = useI18n()

const emitAction = (action: TenantTableContextAction): void => {
  emit('action', {
    tableUuid: props.tableUuid,
    action,
  })
}
</script>

<template>
  <ContextMenu>
    <ContextMenuTrigger as-child>
      <slot />
    </ContextMenuTrigger>
    <ContextMenuContent class="w-52 rounded-lg border bg-popover/95 p-1 shadow-lg backdrop-blur">
      <ContextMenuItem class="h-8 gap-2 rounded-md text-xs" @select="emitAction('query')">
        <IconSearch class="size-4" />
        <span>{{ t('platform.workbench.tenantdb.contextMenu.queryData') }}</span>
      </ContextMenuItem>
      <ContextMenuItem class="h-8 gap-2 rounded-md text-xs" @select="emitAction('schema')">
        <IconEdit class="size-4" />
        <span>{{ t('platform.workbench.tenantdb.contextMenu.editSchema') }}</span>
      </ContextMenuItem>
      <ContextMenuItem class="h-8 gap-2 rounded-md text-xs" @select="emitAction('insert')">
        <IconPlus class="size-4" />
        <span>{{ t('platform.workbench.tenantdb.contextMenu.insertRow') }}</span>
      </ContextMenuItem>
      <ContextMenuSeparator />
      <ContextMenuItem variant="destructive" class="h-8 gap-2 rounded-md text-xs" @select="emitAction('delete')">
        <IconTrash class="size-4" />
        <span>{{ t('platform.workbench.tenantdb.contextMenu.deleteTable') }}</span>
      </ContextMenuItem>
    </ContextMenuContent>
  </ContextMenu>
</template>
