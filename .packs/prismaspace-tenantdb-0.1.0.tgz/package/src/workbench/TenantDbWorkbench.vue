<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { useMutation, useQuery, useQueryClient } from '@tanstack/vue-query'
import { useI18n } from 'vue-i18n'
import type { PrismaspaceClient } from '@prismaspace/sdk'
import { prismaspaceQueryKeys } from '@prismaspace/resources-core'
import {
  IconPlus,
  IconTrash,
} from '@tabler/icons-vue'
import type {
  JsonRecord,
  TenantColumnCreate,
  TenantColumnRead,
  TenantColumnUpdate,
  TenantDataType,
  TenantDbExecutionRequest,
  TenantDbFilterOperator,
  TenantTableCreateRequest,
  TenantTableRead,
  TenantTableUpdateRequest,
} from '@prismaspace/contracts'
import {
  type TenantExplorerActionPayload,
} from './types/tenantdb-ide'
import TenantDbIdeWorkbench from './TenantDbIdeWorkbench.vue'
import TenantDbQueryBuilderDialog from './dialogs/TenantDbQueryBuilderDialog.vue'
import TenantDbTableSchemaDialog from './dialogs/TenantDbTableSchemaDialog.vue'
import TenantDbWorkbenchScaffold from './TenantDbWorkbenchScaffold.vue'
import { Alert, AlertDescription, AlertTitle } from '@prismaspace/ui-shadcn/components/ui/alert'
import { Button } from '@prismaspace/ui-shadcn/components/ui/button'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@prismaspace/ui-shadcn/components/ui/card'
import { Checkbox } from '@prismaspace/ui-shadcn/components/ui/checkbox'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@prismaspace/ui-shadcn/components/ui/dialog'
import { Input } from '@prismaspace/ui-shadcn/components/ui/input'
import { Label } from '@prismaspace/ui-shadcn/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@prismaspace/ui-shadcn/components/ui/select'

const props = defineProps<{
  client: PrismaspaceClient
  workspaceUuid: string
  resourceUuid: string
  workspaceInstanceUuid?: string | null
  latestPublishedInstanceUuid?: string | null
  onBack?: () => void
  onError?: (error: unknown) => void
}>()
const { t } = useI18n()
const emitBusinessError = (error: unknown): void => {
  props.onError?.(error)
}
const tenantdbApi = props.client.tenantdb
const resourceApi = props.client.resource
const platformQueryKeys = prismaspaceQueryKeys

const queryClient = useQueryClient()

const resourceDetailQuery = useQuery({
  queryKey: computed(() => prismaspaceQueryKeys.resourceDetail(props.resourceUuid)),
  enabled: computed(() => Boolean(props.resourceUuid)),
  queryFn: async () => props.client.resource.getResource(props.resourceUuid),
})

const IDENTIFIER_REGEX = /^[a-zA-Z_][a-zA-Z0-9_]*$/
const FILTER_OPERATORS: TenantDbFilterOperator[] = ['=', '!=', '>', '<', '>=', '<=', 'like', 'in', 'not in']
const DATA_TYPES: TenantDataType[] = ['text', 'number', 'integer', 'boolean', 'timestamp', 'json']
const SYSTEM_COLUMNS = new Set(['id', 'created_at'])
const PG_RESERVED_WORDS = new Set([
  'all', 'analyse', 'analyze', 'and', 'any', 'array', 'as', 'asc', 'asymmetric', 'authorization', 'binary',
  'both', 'case', 'cast', 'check', 'collate', 'column', 'concurrently', 'constraint', 'create', 'cross',
  'current_catalog', 'current_date', 'current_role', 'current_time', 'current_timestamp', 'current_user',
  'default', 'deferrable', 'desc', 'distinct', 'do', 'else', 'end', 'except', 'false', 'fetch', 'for', 'foreign',
  'freeze', 'from', 'full', 'grant', 'group', 'having', 'ilike', 'in', 'initially', 'inner', 'intersect', 'into',
  'is', 'isnull', 'join', 'lateral', 'leading', 'left', 'like', 'limit', 'localtime', 'localtimestamp', 'natural',
  'not', 'notnull', 'null', 'offset', 'on', 'only', 'or', 'order', 'outer', 'overlaps', 'placing', 'primary',
  'references', 'returning', 'right', 'select', 'session_user', 'similar', 'some', 'symmetric', 'table',
  'tablesample', 'then', 'to', 'trailing', 'true', 'union', 'unique', 'user', 'using', 'variadic', 'verbose',
  'when', 'where', 'window', 'with',
])

interface TenantColumnDraft {
  uuid?: string
  name: string
  label: string
  description: string
  data_type: TenantDataType
  is_nullable: boolean
  is_unique: boolean
  is_indexed: boolean
  is_vector_enabled: boolean
  default_value_text: string
}

interface TenantTableDraft {
  name: string
  label: string
  description: string
  columns: TenantColumnDraft[]
}

interface TenantFilterDraft {
  id: string
  column: string
  operator: TenantDbFilterOperator
  value: string
}

interface TenantDataQueryState {
  page: number
  limit: number
  orderBy?: string
  columns?: string[]
  filters?: [string, TenantDbFilterOperator, unknown][]
}

interface TenantSchemaDiff {
  tableChanged: boolean
  added: string[]
  updated: string[]
  removed: string[]
}

interface QueryRowsResult {
  rows: JsonRecord[]
  count: number
}

const createId = (): string => `${Date.now()}-${Math.random().toString(16).slice(2)}`

const isSystemColumn = (column: Pick<TenantColumnRead, 'name'> | Pick<TenantColumnDraft, 'name'>): boolean =>
  SYSTEM_COLUMNS.has(column.name)

const formatValueText = (value: unknown): string => {
  if (value === undefined) {
    return ''
  }
  if (value === null) {
    return 'null'
  }
  if (typeof value === 'object') {
    try {
      return JSON.stringify(value)
    } catch {
      return ''
    }
  }
  return String(value)
}

const columnToDraft = (column: TenantColumnRead): TenantColumnDraft => ({
  uuid: column.uuid,
  name: column.name,
  label: column.label ?? column.name,
  description: column.description ?? '',
  data_type: column.data_type,
  is_nullable: column.is_nullable,
  is_unique: column.is_unique,
  is_indexed: column.is_indexed,
  is_vector_enabled: column.is_vector_enabled,
  default_value_text: formatValueText(column.default_value),
})

const createEmptyColumnDraft = (): TenantColumnDraft => ({
  name: '',
  label: '',
  description: '',
  data_type: 'text',
  is_nullable: true,
  is_unique: false,
  is_indexed: false,
  is_vector_enabled: false,
  default_value_text: '',
})

const createDefaultTableDraft = (): TenantTableDraft => ({
  name: '',
  label: '',
  description: '',
  columns: [createEmptyColumnDraft()],
})

const coerceBoolean = (value: string): boolean => {
  const normalized = value.trim().toLowerCase()
  if (normalized === 'true' || normalized === '1' || normalized === 'yes') {
    return true
  }
  if (normalized === 'false' || normalized === '0' || normalized === 'no') {
    return false
  }
  throw new Error(t('platform.workbench.tenantdb.errors.booleanInvalid', { value }))
}

const parseValueByType = (
  rawValue: string,
  dataType: TenantDataType,
  nullable: boolean,
): unknown | undefined => {
  const trimmed = rawValue.trim()
  if (!trimmed) {
    return undefined
  }
  if (trimmed.toLowerCase() === 'null') {
    if (!nullable) {
      throw new Error(t('platform.workbench.tenantdb.errors.nullNotAllowed'))
    }
    return null
  }
  if (dataType === 'text' || dataType === 'timestamp') {
    return rawValue
  }
  if (dataType === 'integer') {
    const parsed = Number(trimmed)
    if (!Number.isInteger(parsed)) {
      throw new Error(t('platform.workbench.tenantdb.errors.integerRequired', { value: rawValue }))
    }
    return parsed
  }
  if (dataType === 'number') {
    const parsed = Number(trimmed)
    if (Number.isNaN(parsed)) {
      throw new Error(t('platform.workbench.tenantdb.errors.numberRequired', { value: rawValue }))
    }
    return parsed
  }
  if (dataType === 'boolean') {
    return coerceBoolean(trimmed)
  }
  if (dataType === 'json') {
    try {
      return JSON.parse(rawValue)
    } catch {
      throw new Error(t('platform.workbench.tenantdb.errors.jsonInvalid'))
    }
  }
  return rawValue
}

const validateIdentifier = (value: string, label: string): string | null => {
  const trimmed = value.trim()
  if (!trimmed) {
    return t('platform.workbench.tenantdb.errors.identifierRequired', { label })
  }
  if (trimmed.length > 63) {
    return t('platform.workbench.tenantdb.errors.identifierLength', { label })
  }
  if (!IDENTIFIER_REGEX.test(trimmed)) {
    return t('platform.workbench.tenantdb.errors.identifierPattern', { label })
  }
  if (PG_RESERVED_WORDS.has(trimmed.toLowerCase())) {
    return t('platform.workbench.tenantdb.errors.identifierReservedKeyword', { label, value: trimmed })
  }
  return null
}

const validateTableDraft = (draft: TenantTableDraft): string[] => {
  const errors: string[] = []
  const tableNameError = validateIdentifier(draft.name, t('platform.workbench.tenantdb.tableName'))
  if (tableNameError) {
    errors.push(tableNameError)
  }
  if (!draft.label.trim()) {
    errors.push(t('platform.workbench.tenantdb.errors.tableLabelRequired'))
  }
  if (!draft.columns.length) {
    errors.push(t('platform.workbench.tenantdb.errors.atLeastOneColumn'))
  }
  const columnNameSet = new Set<string>()
  draft.columns.forEach((column, index) => {
    const prefix = t('platform.workbench.tenantdb.columnIndex', { index: index + 1 })
    const nameError = validateIdentifier(column.name, t('platform.workbench.tenantdb.columnNameWithPrefix', { prefix }))
    if (nameError) {
      errors.push(nameError)
    }
    if (SYSTEM_COLUMNS.has(column.name.trim().toLowerCase())) {
      errors.push(t('platform.workbench.tenantdb.errors.columnReserved', { prefix, value: column.name }))
    }
    const lowered = column.name.trim().toLowerCase()
    if (lowered && columnNameSet.has(lowered)) {
      errors.push(t('platform.workbench.tenantdb.errors.columnDuplicate', { prefix, value: column.name }))
    }
    if (lowered) {
      columnNameSet.add(lowered)
    }
    if (!column.label.trim()) {
      errors.push(t('platform.workbench.tenantdb.errors.columnLabelRequired', { prefix }))
    }
    if (column.default_value_text.trim()) {
      try {
        parseValueByType(column.default_value_text, column.data_type, column.is_nullable)
      } catch (error) {
        errors.push(
          t('platform.workbench.tenantdb.errors.columnDefaultInvalid', {
            prefix,
            message: error instanceof Error ? error.message : t('platform.workbench.tenantdb.errors.invalidValue'),
          }),
        )
      }
    }
  })
  return errors
}

const buildColumnPayload = (
  column: TenantColumnDraft,
): TenantColumnCreate | TenantColumnUpdate => {
  const defaultValueParsed = parseValueByType(column.default_value_text, column.data_type, column.is_nullable)
  const basePayload: TenantColumnCreate = {
    name: column.name.trim(),
    label: column.label.trim(),
    description: column.description.trim() || undefined,
    data_type: column.data_type,
    is_nullable: column.is_nullable,
    is_unique: column.is_unique,
    is_indexed: column.is_indexed,
    is_vector_enabled: column.is_vector_enabled,
    default_value: defaultValueParsed,
  }
  if (column.uuid) {
    return {
      ...basePayload,
      uuid: column.uuid,
    }
  }
  return basePayload
}

const buildTableCreatePayload = (draft: TenantTableDraft): TenantTableCreateRequest => ({
  name: draft.name.trim(),
  label: draft.label.trim(),
  description: draft.description.trim() || undefined,
  columns: draft.columns.map((column) => buildColumnPayload(column) as TenantColumnCreate),
})

const buildTableUpdatePayload = (draft: TenantTableDraft): TenantTableUpdateRequest => ({
  name: draft.name.trim(),
  label: draft.label.trim(),
  description: draft.description.trim() || undefined,
  columns: draft.columns.map((column) => buildColumnPayload(column)),
})

const buildSchemaDiff = (source: TenantTableRead | null, draft: TenantTableDraft | null): TenantSchemaDiff => {
  if (!source || !draft) {
    return {
      tableChanged: false,
      added: [],
      updated: [],
      removed: [],
    }
  }
  const sourceColumns = source.columns.filter((column) => !isSystemColumn(column))
  const sourceByUuid = new Map(sourceColumns.map((column) => [column.uuid, column]))
  const draftByUuid = new Map(
    draft.columns
      .filter((column) => Boolean(column.uuid))
      .map((column) => [column.uuid as string, column]),
  )

  const added = draft.columns
    .filter((column) => !column.uuid)
    .map((column) => column.name || t('platform.workbench.tenantdb.unnamed'))

  const updated: string[] = []
  draft.columns.forEach((column) => {
    if (!column.uuid) {
      return
    }
    const sourceColumn = sourceByUuid.get(column.uuid)
    if (!sourceColumn) {
      return
    }
    const sourceDefault = formatValueText(sourceColumn.default_value)
    if (
      sourceColumn.name !== column.name
      || (sourceColumn.label ?? '') !== column.label
      || (sourceColumn.description ?? '') !== column.description
      || sourceColumn.data_type !== column.data_type
      || sourceColumn.is_nullable !== column.is_nullable
      || sourceColumn.is_unique !== column.is_unique
      || sourceColumn.is_indexed !== column.is_indexed
      || sourceColumn.is_vector_enabled !== column.is_vector_enabled
      || sourceDefault !== column.default_value_text
    ) {
      updated.push(sourceColumn.name)
    }
  })

  const removed = sourceColumns
    .filter((column) => !draftByUuid.has(column.uuid))
    .map((column) => column.name)

  return {
    tableChanged:
      source.name !== draft.name.trim()
      || (source.label ?? '') !== draft.label.trim()
      || (source.description ?? '') !== draft.description.trim(),
    added,
    updated,
    removed,
  }
}

const formatCell = (value: unknown): string => {
  if (value === null) {
    return t('platform.workbench.tenantdb.valueNull')
  }
  if (value === undefined) {
    return ''
  }
  if (typeof value === 'object') {
    try {
      return JSON.stringify(value)
    } catch {
      return t('platform.workbench.tenantdb.valueObject')
    }
  }
  return String(value)
}

const selectedTableUuid = ref('')
const tableSearchText = ref('')
const activeMainTab = ref<'data' | 'sql'>('data')

const queryDialogOpen = ref(false)
const schemaDialogOpen = ref(false)

const schemaDraft = ref<TenantTableDraft | null>(null)
const selectedSchemaColumnId = ref<string>('')
const schemaErrorText = ref('')
const schemaConfirmDialogOpen = ref(false)
const schemaDeleteAcknowledge = ref(false)

const createTableDialogOpen = ref(false)
const createDraft = ref<TenantTableDraft>(createDefaultTableDraft())
const createErrorText = ref('')

const deleteTableDialogOpen = ref(false)
const deleteTableConfirmInput = ref('')

const dataFilterDrafts = ref<TenantFilterDraft[]>([])
const dataColumnDrafts = ref<string[]>([])
const dataOrderColumnDraft = ref('')
const dataOrderDirectionDraft = ref<'ASC' | 'DESC'>('DESC')
const dataLimitDraft = ref(25)

const appliedDataQuery = ref<TenantDataQueryState>({
  page: 1,
  limit: 25,
})

const insertDialogOpen = ref(false)
const insertRowInputs = ref<Record<string, string>>({})

const rowEditDialogOpen = ref(false)
const editingRow = ref<JsonRecord | null>(null)
const editRowInputs = ref<Record<string, string>>({})

const rowDeleteDialogOpen = ref(false)
const deleteRowTargetId = ref<string>('')
const deleteRowConfirmInput = ref('')

const sqlText = ref('')
const sqlResultRows = ref<JsonRecord[]>([])
const sqlResultError = ref('')

const tablesQuery = useQuery({
  queryKey: computed(() => platformQueryKeys.tenantTables(props.workspaceInstanceUuid ?? 'none')),
  enabled: computed(() => Boolean(props.workspaceInstanceUuid)),
  queryFn: async () => tenantdbApi.listTables(props.workspaceInstanceUuid as string),
})

const selectedTableQuery = useQuery({
  queryKey: computed(() =>
    platformQueryKeys.tenantTableDetail(props.workspaceInstanceUuid ?? 'none', selectedTableUuid.value || 'none')),
  enabled: computed(() => Boolean(props.workspaceInstanceUuid && selectedTableUuid.value)),
  queryFn: async () => tenantdbApi.getTable(props.workspaceInstanceUuid as string, selectedTableUuid.value),
})

const selectedTable = computed(() => selectedTableQuery.data.value ?? null)
const editableColumns = computed(() => selectedTable.value?.columns.filter((column) => !isSystemColumn(column)) ?? [])

const schemaDiff = computed(() => buildSchemaDiff(selectedTable.value, schemaDraft.value))
const hasSchemaChanges = computed(() => {
  const diff = schemaDiff.value
  return diff.tableChanged || diff.added.length > 0 || diff.updated.length > 0 || diff.removed.length > 0
})

const dataQuerySignature = computed(() => JSON.stringify(appliedDataQuery.value))

const rowsQuery = useQuery({
  queryKey: computed(() =>
    platformQueryKeys.tenantTableRows(
      props.workspaceInstanceUuid ?? 'none',
      selectedTableUuid.value || 'none',
      dataQuerySignature.value,
    )),
  enabled: computed(() => Boolean(props.workspaceInstanceUuid && selectedTable.value)),
  queryFn: async (): Promise<QueryRowsResult> => {
    const table = selectedTable.value
    if (!table) {
      return { rows: [], count: 0 }
    }
    const payload: TenantDbExecutionRequest = {
      inputs: {
        action: 'query',
        table_name: table.name,
        page: appliedDataQuery.value.page,
        limit: appliedDataQuery.value.limit,
        order_by: appliedDataQuery.value.orderBy,
        columns: appliedDataQuery.value.columns?.length ? appliedDataQuery.value.columns : undefined,
        filters: appliedDataQuery.value.filters?.length ? appliedDataQuery.value.filters : undefined,
      },
    }
    const result = await tenantdbApi.execute(props.workspaceInstanceUuid as string, payload)
    if (!Array.isArray(result.data)) {
      return {
        rows: [],
        count: 0,
      }
    }
    return {
      rows: result.data,
      count: result.count ?? result.data.length,
    }
  },
})

const dataRows = computed(() => rowsQuery.data.value?.rows ?? [])
const dataTotalCount = computed(() => rowsQuery.data.value?.count ?? 0)
const dataPageCount = computed(() => Math.max(1, Math.ceil(dataTotalCount.value / Math.max(1, appliedDataQuery.value.limit))))

const dataVisibleColumns = computed(() => {
  const table = selectedTable.value
  if (!table) {
    return []
  }
  if (appliedDataQuery.value.columns?.length) {
    const columnSet = new Set(appliedDataQuery.value.columns)
    return table.columns.map((column) => column.name).filter((name) => columnSet.has(name))
  }
  return table.columns.map((column) => column.name)
})

const sqlResultColumns = computed(() => {
  const first = sqlResultRows.value[0]
  if (!first) {
    return []
  }
  return Object.keys(first)
})

watch(
  () => tablesQuery.data.value,
  (tables) => {
    if (!tables?.length) {
      selectedTableUuid.value = ''
      return
    }
    if (!selectedTableUuid.value || !tables.some((table) => table.uuid === selectedTableUuid.value)) {
      selectedTableUuid.value = tables[0]?.uuid ?? ''
    }
  },
  { immediate: true },
)

watch(
  selectedTable,
  (table) => {
    if (!table) {
      schemaDraft.value = null
      selectedSchemaColumnId.value = ''
      return
    }
    schemaDraft.value = {
      name: table.name,
      label: table.label ?? table.name,
      description: table.description ?? '',
      columns: table.columns.filter((column) => !isSystemColumn(column)).map((column) => columnToDraft(column)),
    }
    selectedSchemaColumnId.value = schemaDraft.value.columns[0]?.uuid ?? schemaDraft.value.columns[0]?.name ?? ''
    schemaErrorText.value = ''

    const availableColumns = table.columns.map((column) => column.name)
    dataColumnDrafts.value = availableColumns
    dataOrderColumnDraft.value = availableColumns[0] ?? ''
    dataFilterDrafts.value = []
    dataLimitDraft.value = 25
    appliedDataQuery.value = {
      page: 1,
      limit: 25,
      columns: undefined,
      orderBy: undefined,
      filters: undefined,
    }

    sqlText.value = `SELECT * FROM ${table.name} ORDER BY id DESC LIMIT 50;`
    sqlResultRows.value = []
    sqlResultError.value = ''
  },
  { immediate: true },
)

const invalidateTenantQueries = async (): Promise<void> => {
  const instanceUuid = props.workspaceInstanceUuid
  if (!instanceUuid) {
    return
  }
  await Promise.all([
    queryClient.invalidateQueries({
      queryKey: platformQueryKeys.tenantTables(instanceUuid),
    }),
    selectedTableUuid.value
      ? queryClient.invalidateQueries({
          queryKey: platformQueryKeys.tenantTableDetail(instanceUuid, selectedTableUuid.value),
        })
      : Promise.resolve(),
    selectedTableUuid.value
      ? queryClient.invalidateQueries({
          queryKey: ['tenantdb', instanceUuid, selectedTableUuid.value, 'rows'],
        })
      : Promise.resolve(),
  ])
}

const createTableMutation = useMutation({
  mutationFn: async (payload: TenantTableCreateRequest) => {
    if (!props.workspaceInstanceUuid) {
      throw new Error(t('platform.workbench.tenantdb.errors.workspaceInstanceMissing'))
    }
    return tenantdbApi.createTable(props.workspaceInstanceUuid, payload)
  },
  onSuccess: async (createdTable) => {
    await invalidateTenantQueries()
    selectedTableUuid.value = createdTable.uuid
    createTableDialogOpen.value = false
    createErrorText.value = ''
  },
  onError: (error) => {
    emitBusinessError(error)
  },
})

const updateTableMutation = useMutation({
  mutationFn: async (payload: TenantTableUpdateRequest) => {
    if (!props.workspaceInstanceUuid || !selectedTableUuid.value) {
      throw new Error(t('platform.workbench.tenantdb.errors.tableContextMissing'))
    }
    return tenantdbApi.updateTable(props.workspaceInstanceUuid, selectedTableUuid.value, payload)
  },
  onSuccess: async () => {
    schemaConfirmDialogOpen.value = false
    schemaDialogOpen.value = false
    schemaDeleteAcknowledge.value = false
    schemaErrorText.value = ''
    await invalidateTenantQueries()
    await selectedTableQuery.refetch()
  },
  onError: (error) => {
    emitBusinessError(error)
  },
})

const deleteTableMutation = useMutation({
  mutationFn: async () => {
    if (!props.workspaceInstanceUuid || !selectedTableUuid.value) {
      throw new Error(t('platform.workbench.tenantdb.errors.tableContextMissing'))
    }
    return tenantdbApi.deleteTable(props.workspaceInstanceUuid, selectedTableUuid.value)
  },
  onSuccess: async () => {
    deleteTableDialogOpen.value = false
    deleteTableConfirmInput.value = ''
    await invalidateTenantQueries()
  },
  onError: (error) => {
    emitBusinessError(error)
  },
})

const insertRowMutation = useMutation({
  mutationFn: async (payload: JsonRecord) => {
    if (!props.workspaceInstanceUuid || !selectedTable.value) {
      throw new Error(t('platform.workbench.tenantdb.errors.tableContextMissing'))
    }
    return tenantdbApi.execute(props.workspaceInstanceUuid, {
      inputs: {
        action: 'insert',
        table_name: selectedTable.value.name,
        payload,
      },
    })
  },
  onSuccess: async () => {
    insertDialogOpen.value = false
    await invalidateTenantQueries()
  },
  onError: (error) => {
    emitBusinessError(error)
  },
})

const updateRowMutation = useMutation({
  mutationFn: async ({ rowId, payload }: { rowId: string; payload: JsonRecord }) => {
    if (!props.workspaceInstanceUuid || !selectedTable.value) {
      throw new Error(t('platform.workbench.tenantdb.errors.tableContextMissing'))
    }
    return tenantdbApi.execute(props.workspaceInstanceUuid, {
      inputs: {
        action: 'update',
        table_name: selectedTable.value.name,
        filters: {
          id: rowId,
        },
        payload,
      },
    })
  },
  onSuccess: async () => {
    rowEditDialogOpen.value = false
    editingRow.value = null
    await invalidateTenantQueries()
  },
  onError: (error) => {
    emitBusinessError(error)
  },
})

const deleteRowMutation = useMutation({
  mutationFn: async (rowId: string) => {
    if (!props.workspaceInstanceUuid || !selectedTable.value) {
      throw new Error(t('platform.workbench.tenantdb.errors.tableContextMissing'))
    }
    return tenantdbApi.execute(props.workspaceInstanceUuid, {
      inputs: {
        action: 'delete',
        table_name: selectedTable.value.name,
        filters: {
          id: rowId,
        },
      },
    })
  },
  onSuccess: async () => {
    rowDeleteDialogOpen.value = false
    deleteRowTargetId.value = ''
    deleteRowConfirmInput.value = ''
    await invalidateTenantQueries()
  },
  onError: (error) => {
    emitBusinessError(error)
  },
})

const sqlMutation = useMutation({
  mutationFn: async (rawSql: string): Promise<JsonRecord[]> => {
    if (!props.workspaceInstanceUuid || !selectedTable.value) {
      throw new Error(t('platform.workbench.tenantdb.errors.tableContextMissing'))
    }
    const response = await tenantdbApi.execute(props.workspaceInstanceUuid, {
      inputs: {
        action: 'raw_sql',
        table_name: selectedTable.value.name,
        raw_sql: rawSql,
      },
    })
    if (!Array.isArray(response.data)) {
      return []
    }
    return response.data
  },
  onSuccess: (rows, sql) => {
    sqlResultRows.value = rows
    sqlResultError.value = ''
  },
  onError: (error, sql) => {
    sqlResultRows.value = []
    sqlResultError.value = error instanceof Error ? error.message : t('platform.workbench.tenantdb.errors.sqlExecutionFailed')
    emitBusinessError(error)
  },
})

const buildPublishVersionTag = (): string => {
  const now = new Date()
  const pad = (value: number, length = 2): string => String(value).padStart(length, '0')
  return `v${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}${pad(now.getMilliseconds(), 3)}`
}

const publishMutation = useMutation({
  mutationFn: async () => {
    if (!props.workspaceInstanceUuid) {
      throw new Error(t('platform.workbench.tenantdb.errors.noWorkspaceInstance'))
    }
    return resourceApi.publishInstance(props.workspaceInstanceUuid, {
      version_tag: buildPublishVersionTag(),
    })
  },
  onError: (error) => {
    emitBusinessError(error)
  },
})

const openCreateTableDialog = (): void => {
  createDraft.value = createDefaultTableDraft()
  createErrorText.value = ''
  createTableDialogOpen.value = true
}

const addColumnToCreateDraft = (): void => {
  createDraft.value.columns.push(createEmptyColumnDraft())
}

const removeColumnFromCreateDraft = (index: number): void => {
  createDraft.value.columns.splice(index, 1)
  if (!createDraft.value.columns.length) {
    createDraft.value.columns.push(createEmptyColumnDraft())
  }
}

const submitCreateTable = async (): Promise<void> => {
  const validationErrors = validateTableDraft(createDraft.value)
  if (validationErrors.length) {
    createErrorText.value = validationErrors.join(' ')
    return
  }
  try {
    const payload = buildTableCreatePayload(createDraft.value)
    await createTableMutation.mutateAsync(payload)
  } catch (error) {
    createErrorText.value = error instanceof Error ? error.message : t('platform.workbench.tenantdb.errors.createPayloadFailed')
  }
}

const addSchemaColumn = (): void => {
  if (!schemaDraft.value) {
    return
  }
  const nextColumn = createEmptyColumnDraft()
  schemaDraft.value.columns.push(nextColumn)
  selectedSchemaColumnId.value = nextColumn.name || createId()
}

const removeSchemaColumn = (index: number): void => {
  if (!schemaDraft.value) {
    return
  }
  schemaDraft.value.columns.splice(index, 1)
  if (!schemaDraft.value.columns.length) {
    const nextColumn = createEmptyColumnDraft()
    schemaDraft.value.columns.push(nextColumn)
  }
  const current = schemaDraft.value.columns[0]
  selectedSchemaColumnId.value = current ? (current.uuid ?? current.name) : ''
}

const openSchemaSaveConfirm = (): void => {
  if (!schemaDraft.value) {
    return
  }
  const validationErrors = validateTableDraft(schemaDraft.value)
  if (validationErrors.length) {
    schemaErrorText.value = validationErrors.join(' ')
    return
  }
  if (!hasSchemaChanges.value) {
    schemaErrorText.value = t('platform.workbench.tenantdb.errors.noSchemaChanges')
    return
  }
  schemaErrorText.value = ''
  schemaDeleteAcknowledge.value = false
  schemaConfirmDialogOpen.value = true
}

const submitSchemaUpdate = async (): Promise<void> => {
  if (!schemaDraft.value) {
    return
  }
  if (schemaDiff.value.removed.length > 0 && !schemaDeleteAcknowledge.value) {
    schemaErrorText.value = t('platform.workbench.tenantdb.errors.schemaDeleteAckRequired')
    return
  }
  try {
    const payload = buildTableUpdatePayload(schemaDraft.value)
    await updateTableMutation.mutateAsync(payload)
  } catch (error) {
    schemaErrorText.value = error instanceof Error ? error.message : t('platform.workbench.tenantdb.errors.updatePayloadFailed')
  }
}

const openDeleteTableDialog = (): void => {
  deleteTableDialogOpen.value = true
  deleteTableConfirmInput.value = ''
}

const submitDeleteTable = async (): Promise<void> => {
  if (!selectedTable.value) {
    return
  }
  if (deleteTableConfirmInput.value !== selectedTable.value.name) {
    schemaErrorText.value = t('platform.workbench.tenantdb.errors.deleteTableConfirmMismatch')
    return
  }
  await deleteTableMutation.mutateAsync()
}

const toggleDataColumn = (name: string, checked: boolean): void => {
  const next = new Set(dataColumnDrafts.value)
  if (checked) {
    next.add(name)
  } else {
    next.delete(name)
  }
  dataColumnDrafts.value = Array.from(next)
}

const addFilterDraft = (): void => {
  const firstColumn = selectedTable.value?.columns[0]?.name ?? ''
  dataFilterDrafts.value.push({
    id: createId(),
    column: firstColumn,
    operator: '=',
    value: '',
  })
}

const removeFilterDraft = (id: string): void => {
  dataFilterDrafts.value = dataFilterDrafts.value.filter((filter) => filter.id !== id)
}

const updateFilterDraft = (
  payload: { id: string; column?: string; operator?: TenantDbFilterOperator; value?: string },
): void => {
  dataFilterDrafts.value = dataFilterDrafts.value.map((filter) => {
    if (filter.id !== payload.id) {
      return filter
    }
    return {
      ...filter,
      column: payload.column ?? filter.column,
      operator: payload.operator ?? filter.operator,
      value: payload.value ?? filter.value,
    }
  })
}

const parseFilterValue = (column: TenantColumnRead | undefined, rawValue: string, operator: TenantDbFilterOperator): unknown => {
  if (!column) {
    return rawValue
  }
  if (operator === 'in' || operator === 'not in') {
    return rawValue
      .split(',')
      .map((item) => item.trim())
      .filter(Boolean)
      .map((item) => parseValueByType(item, column.data_type, true))
      .filter((item) => item !== undefined)
  }
  const parsed = parseValueByType(rawValue, column.data_type, true)
  return parsed ?? rawValue
}

const applyDataQuery = (): void => {
  if (!selectedTable.value) {
    return
  }
  const table = selectedTable.value
  const tableColumnMap = new Map(table.columns.map((column) => [column.name, column]))
  try {
    const filters = dataFilterDrafts.value
      .filter((filter) => filter.column && filter.value.trim())
      .map((filter) => {
        const column = tableColumnMap.get(filter.column)
        return [filter.column, filter.operator, parseFilterValue(column, filter.value, filter.operator)] as [string, TenantDbFilterOperator, unknown]
      })

    const selectedColumns = dataColumnDrafts.value.filter((name) => tableColumnMap.has(name))
    appliedDataQuery.value = {
      page: 1,
      limit: dataLimitDraft.value,
      columns: selectedColumns.length === table.columns.length ? undefined : selectedColumns,
      orderBy: dataOrderColumnDraft.value ? `${dataOrderColumnDraft.value} ${dataOrderDirectionDraft.value}` : undefined,
      filters: filters.length ? filters : undefined,
    }
  } catch (error) {
    emitBusinessError(error)
  }
}

const applyDataQueryAndClose = (): void => {
  applyDataQuery()
  queryDialogOpen.value = false
}

const buildRowInputMap = (row?: JsonRecord): Record<string, string> => {
  const result: Record<string, string> = {}
  editableColumns.value.forEach((column) => {
    result[column.name] = row ? formatCell(row[column.name]) : ''
  })
  return result
}

const openInsertRowDialog = (): void => {
  insertRowInputs.value = buildRowInputMap()
  insertDialogOpen.value = true
}

const submitInsertRow = async (): Promise<void> => {
  const payload: JsonRecord = {}
  for (const column of editableColumns.value) {
    const rawValue = insertRowInputs.value[column.name] ?? ''
    const parsed = parseValueByType(rawValue, column.data_type, column.is_nullable)
    if (parsed === undefined) {
      continue
    }
    payload[column.name] = parsed
  }
  await insertRowMutation.mutateAsync(payload)
}

const openEditRowDialog = (row: JsonRecord): void => {
  editingRow.value = row
  editRowInputs.value = buildRowInputMap(row)
  rowEditDialogOpen.value = true
}

const submitEditRow = async (): Promise<void> => {
  const row = editingRow.value
  if (!row) {
    return
  }
  const rowId = String(row.id ?? '')
  if (!rowId) {
    emitBusinessError(new Error(t('platform.workbench.tenantdb.errors.rowIdMissing')))
    return
  }
  const payload: JsonRecord = {}
  for (const column of editableColumns.value) {
    const rawValue = editRowInputs.value[column.name] ?? ''
    const parsed = parseValueByType(rawValue, column.data_type, column.is_nullable)
    if (parsed === undefined) {
      continue
    }
    payload[column.name] = parsed
  }
  await updateRowMutation.mutateAsync({
    rowId,
    payload,
  })
}

const openDeleteRowDialog = (row: JsonRecord): void => {
  const rowId = String(row.id ?? '')
  if (!rowId) {
    emitBusinessError(new Error(t('platform.workbench.tenantdb.errors.rowIdMissing')))
    return
  }
  deleteRowTargetId.value = rowId
  deleteRowConfirmInput.value = ''
  rowDeleteDialogOpen.value = true
}

const submitDeleteRow = async (): Promise<void> => {
  if (!deleteRowTargetId.value) {
    return
  }
  if (deleteRowConfirmInput.value !== deleteRowTargetId.value) {
    emitBusinessError(new Error(t('platform.workbench.tenantdb.errors.rowDeleteConfirmMismatch')))
    return
  }
  await deleteRowMutation.mutateAsync(deleteRowTargetId.value)
}

const runSql = async (): Promise<void> => {
  const sql = sqlText.value.trim()
  if (!sql) {
    return
  }
  if (!/^select/i.test(sql)) {
    sqlResultError.value = t('platform.workbench.tenantdb.errors.rawSqlSelectOnly')
    return
  }
  await sqlMutation.mutateAsync(sql)
}

const openQueryBuilder = (): void => {
  if (!selectedTable.value) {
    return
  }
  activeMainTab.value = 'data'
  queryDialogOpen.value = true
}

const handleHeaderSave = (): void => {
  schemaDialogOpen.value = true
  openSchemaSaveConfirm()
}

const gotoDataPage = (nextPage: number): void => {
  const normalizedPage = Math.max(1, Math.min(nextPage, dataPageCount.value))
  if (normalizedPage === appliedDataQuery.value.page) {
    return
  }
  appliedDataQuery.value = {
    ...appliedDataQuery.value,
    page: normalizedPage,
  }
}

const handleHeaderPublish = (): void => {
  if (publishMutation.isPending.value) {
    return
  }
  publishMutation.mutate()
}

const handleExplorerAction = (payload: TenantExplorerActionPayload): void => {
  selectedTableUuid.value = payload.tableUuid
  if (payload.action === 'query') {
    openQueryBuilder()
    return
  }
  if (payload.action === 'schema') {
    schemaDialogOpen.value = true
    return
  }
  if (payload.action === 'insert') {
    openInsertRowDialog()
    return
  }
  if (payload.action === 'delete') {
    openDeleteTableDialog()
  }
}

</script>

<template>
  <TenantDbWorkbenchScaffold
    :resource-name="resourceDetailQuery.data.value?.name ?? ''"
    :resource-description="resourceDetailQuery.data.value?.description ?? ''"
    :updated-at="resourceDetailQuery.data.value?.updated_at ?? null"
    :workspace-instance-uuid="workspaceInstanceUuid"
    :latest-published-instance-uuid="latestPublishedInstanceUuid"
    :run-visible="false"
    :save-disabled="!hasSchemaChanges || updateTableMutation.isPending.value"
    :publish-disabled="!workspaceInstanceUuid || publishMutation.isPending.value"
    :saving="updateTableMutation.isPending.value"
    :publishing="publishMutation.isPending.value"
    @back="props.onBack?.()"
    @save="handleHeaderSave"
    @publish="handleHeaderPublish"
  >
    <Card v-if="!workspaceInstanceUuid">
      <CardHeader>
        <CardTitle>{{ t('platform.workbench.tenantdb.instanceUnavailableTitle') }}</CardTitle>
      </CardHeader>
      <CardContent class="text-sm text-muted-foreground">
        {{ t('platform.workbench.tenantdb.instanceUnavailableDescription') }}
      </CardContent>
    </Card>

    <div v-else class="h-full min-h-0 flex-1">
      <TenantDbIdeWorkbench
        class="h-full"
        :tables="tablesQuery.data.value ?? []"
        :selected-table-uuid="selectedTableUuid"
        :selected-table="selectedTable"
        :search-text="tableSearchText"
        :active-tab="activeMainTab"
        :rows-loading="rowsQuery.isLoading.value"
        :tables-loading="tablesQuery.isLoading.value"
        :rows="dataRows"
        :visible-columns="dataVisibleColumns"
        :total-count="dataTotalCount"
        :page="appliedDataQuery.page"
        :page-count="dataPageCount"
        :sql-text="sqlText"
        :sql-rows="sqlResultRows"
        :sql-columns="sqlResultColumns"
        :sql-error="sqlResultError"
        :sql-running="sqlMutation.isPending.value"
        @update:search-text="tableSearchText = $event"
        @select-table="selectedTableUuid = $event"
        @open-action="handleExplorerAction"
        @create-table="openCreateTableDialog"
        @update:active-tab="activeMainTab = $event"
        @goto-page="gotoDataPage"
        @query-data="openQueryBuilder"
        @insert-row="openInsertRowDialog"
        @edit-row="openEditRowDialog"
        @delete-row="openDeleteRowDialog"
        @update:sql-text="sqlText = $event"
        @run-sql="runSql"
      />
    </div>

    <TenantDbQueryBuilderDialog
      :open="queryDialogOpen"
      :selected-table="selectedTable"
      :data-limit-draft="dataLimitDraft"
      :data-order-column-draft="dataOrderColumnDraft"
      :data-order-direction-draft="dataOrderDirectionDraft"
      :data-column-drafts="dataColumnDrafts"
      :data-filter-drafts="dataFilterDrafts"
      :filter-operators="FILTER_OPERATORS"
      :applying="rowsQuery.isFetching.value"
      @update:open="queryDialogOpen = $event"
      @update:limit="dataLimitDraft = $event"
      @update:order-column="dataOrderColumnDraft = $event"
      @update:order-direction="dataOrderDirectionDraft = $event"
      @toggle-column="toggleDataColumn($event.name, $event.checked)"
      @add-filter="addFilterDraft"
      @remove-filter="removeFilterDraft"
      @update-filter="updateFilterDraft"
      @apply="applyDataQueryAndClose"
    />

    <TenantDbTableSchemaDialog
      :open="schemaDialogOpen"
      :schema-draft="schemaDraft"
      :selected-column-id="selectedSchemaColumnId"
      :schema-diff="schemaDiff"
      :has-schema-changes="hasSchemaChanges"
      :delete-acknowledge="schemaDeleteAcknowledge"
      :error-text="schemaErrorText"
      :data-types="DATA_TYPES"
      :saving="updateTableMutation.isPending.value"
      @update:open="schemaDialogOpen = $event"
      @update:selected-column-id="selectedSchemaColumnId = $event"
      @update:delete-acknowledge="schemaDeleteAcknowledge = $event"
      @add-column="addSchemaColumn"
      @remove-column="removeSchemaColumn"
      @save="openSchemaSaveConfirm"
    />

    <Dialog :open="createTableDialogOpen" @update:open="createTableDialogOpen = $event">
      <DialogContent class="max-h-[90vh] overflow-y-auto sm:max-w-[920px]">
        <DialogHeader>
          <DialogTitle>{{ t('platform.workbench.tenantdb.createTable') }}</DialogTitle>
          <DialogDescription>{{ t('platform.workbench.tenantdb.createDialogDescription') }}</DialogDescription>
        </DialogHeader>
        <div class="space-y-3">
          <div class="grid gap-2 md:grid-cols-3">
            <div class="space-y-1">
              <Label>{{ t('platform.workbench.tenantdb.name') }}</Label>
              <Input v-model="createDraft.name" class="font-mono" :placeholder="t('platform.workbench.tenantdb.tableNameExample')" />
            </div>
            <div class="space-y-1">
              <Label>{{ t('platform.workbench.tenantdb.label') }}</Label>
              <Input v-model="createDraft.label" :placeholder="t('platform.workbench.tenantdb.tableLabelExample')" />
            </div>
            <div class="space-y-1">
              <Label>{{ t('platform.workbench.tenantdb.description') }}</Label>
              <Input v-model="createDraft.description" :placeholder="t('platform.workbench.tenantdb.optional')" />
            </div>
          </div>

          <div class="space-y-2">
            <div class="flex items-center justify-between">
              <Label>{{ t('platform.workbench.tenantdb.initialColumns') }}</Label>
              <Button size="sm" variant="outline" class="gap-1" @click="addColumnToCreateDraft">
                <IconPlus class="size-3.5" />
                {{ t('platform.workbench.tenantdb.add') }}
              </Button>
            </div>
            <div
              v-for="(column, index) in createDraft.columns"
              :key="`create-col-${index}`"
              class="space-y-2 rounded-md border p-3"
            >
              <div class="grid gap-2 md:grid-cols-[1fr_1fr_140px_120px_120px_120px_auto]">
                <Input v-model="column.name" class="font-mono" :placeholder="t('platform.workbench.tenantdb.columnNamePlaceholder')" />
                <Input v-model="column.label" :placeholder="t('platform.workbench.tenantdb.label')" />
                <Select v-model="column.data_type">
                  <SelectTrigger>
                    <SelectValue :placeholder="t('platform.workbench.tenantdb.type')" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem v-for="dataType in DATA_TYPES" :key="dataType" :value="dataType">
                      {{ dataType }}
                    </SelectItem>
                  </SelectContent>
                </Select>
                <label class="flex items-center gap-1 rounded-md border px-2 text-xs">
                  <Checkbox
                    :model-value="column.is_nullable"
                    @update:model-value="column.is_nullable = Boolean($event)"
                  />
                  {{ t('platform.workbench.tenantdb.nullable') }}
                </label>
                <label class="flex items-center gap-1 rounded-md border px-2 text-xs">
                  <Checkbox
                    :model-value="column.is_unique"
                    @update:model-value="column.is_unique = Boolean($event)"
                  />
                  {{ t('platform.workbench.tenantdb.unique') }}
                </label>
                <label class="flex items-center gap-1 rounded-md border px-2 text-xs">
                  <Checkbox
                    :model-value="column.is_indexed"
                    @update:model-value="column.is_indexed = Boolean($event)"
                  />
                  {{ t('platform.workbench.tenantdb.indexed') }}
                </label>
                <Button size="icon" variant="outline" @click="removeColumnFromCreateDraft(index)">
                  <IconTrash class="size-3.5" />
                </Button>
              </div>
              <div class="grid gap-2 md:grid-cols-[1fr_1fr]">
                <Input
                  v-model="column.default_value_text"
                  class="font-mono"
                  :placeholder="t('platform.workbench.tenantdb.defaultValue')"
                />
                <Input v-model="column.description" :placeholder="t('platform.workbench.tenantdb.description')" />
              </div>
            </div>
          </div>

          <Alert v-if="createErrorText" variant="destructive">
            <AlertTitle>{{ t('platform.workbench.tenantdb.createValidationFailed') }}</AlertTitle>
            <AlertDescription>{{ createErrorText }}</AlertDescription>
          </Alert>
        </div>

        <DialogFooter>
          <Button variant="outline" @click="createTableDialogOpen = false">{{ t('common.cancel') }}</Button>
          <Button :disabled="createTableMutation.isPending.value" @click="submitCreateTable">
            {{ createTableMutation.isPending.value ? t('platform.workbench.tenantdb.creating') : t('platform.workbench.tenantdb.create') }}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>

    <Dialog :open="schemaConfirmDialogOpen" @update:open="schemaConfirmDialogOpen = $event">
      <DialogContent class="sm:max-w-[640px]">
        <DialogHeader>
          <DialogTitle>{{ t('platform.workbench.tenantdb.confirmSchemaSync') }}</DialogTitle>
          <DialogDescription>
            {{ t('platform.workbench.tenantdb.confirmSchemaSyncDescription') }}
          </DialogDescription>
        </DialogHeader>

        <div class="space-y-3 text-sm">
          <p>{{ t('platform.workbench.tenantdb.schemaChanged') }}: <strong>{{ schemaDiff.tableChanged ? t('platform.workbench.tenantdb.yes') : t('platform.workbench.tenantdb.no') }}</strong></p>
          <p>{{ t('platform.workbench.tenantdb.addedColumns') }}: <strong>{{ schemaDiff.added.join(', ') || t('platform.workbench.tenantdb.none') }}</strong></p>
          <p>{{ t('platform.workbench.tenantdb.updatedColumns') }}: <strong>{{ schemaDiff.updated.join(', ') || t('platform.workbench.tenantdb.none') }}</strong></p>
          <p class="text-destructive">
            {{ t('platform.workbench.tenantdb.removedColumns') }}: <strong>{{ schemaDiff.removed.join(', ') || t('platform.workbench.tenantdb.none') }}</strong>
          </p>
          <label
            v-if="schemaDiff.removed.length"
            class="flex items-center gap-2 rounded-md border border-destructive/40 bg-destructive/5 p-2 text-xs"
          >
            <Checkbox :model-value="schemaDeleteAcknowledge" @update:model-value="schemaDeleteAcknowledge = Boolean($event)" />
            <span>{{ t('platform.workbench.tenantdb.destructiveDeleteConfirm') }}</span>
          </label>
        </div>

        <DialogFooter>
          <Button variant="outline" @click="schemaConfirmDialogOpen = false">{{ t('common.cancel') }}</Button>
          <Button :disabled="updateTableMutation.isPending.value" @click="submitSchemaUpdate">
            {{ updateTableMutation.isPending.value ? t('platform.workbench.header.actions.saving') : t('platform.workbench.tenantdb.confirmSave') }}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>

    <Dialog :open="deleteTableDialogOpen" @update:open="deleteTableDialogOpen = $event">
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{{ t('platform.workbench.tenantdb.deleteTable') }}</DialogTitle>
          <DialogDescription>
            {{ t('platform.workbench.tenantdb.deleteTableDescription') }}
          </DialogDescription>
        </DialogHeader>
        <div class="space-y-2">
          <p class="text-sm">
            {{ t('platform.workbench.tenantdb.confirmTarget') }}: <span class="font-mono">{{ selectedTable?.name }}</span>
          </p>
          <Input v-model="deleteTableConfirmInput" class="font-mono" :placeholder="t('platform.workbench.tenantdb.typeTableNameHere')" />
        </div>
        <DialogFooter>
          <Button variant="outline" @click="deleteTableDialogOpen = false">{{ t('common.cancel') }}</Button>
          <Button
            variant="destructive"
            :disabled="deleteTableMutation.isPending.value"
            @click="submitDeleteTable"
          >
            {{ deleteTableMutation.isPending.value ? t('platform.workbench.tenantdb.deleting') : t('platform.workbench.tenantdb.deleteTable') }}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>

    <Dialog :open="insertDialogOpen" @update:open="insertDialogOpen = $event">
      <DialogContent class="sm:max-w-[720px]">
        <DialogHeader>
          <DialogTitle>{{ t('platform.workbench.tenantdb.insertRowTitle') }}</DialogTitle>
          <DialogDescription>{{ t('platform.workbench.tenantdb.insertRowDescription') }}</DialogDescription>
        </DialogHeader>
        <div class="grid gap-2 md:grid-cols-2">
          <div v-for="column in editableColumns" :key="column.uuid" class="space-y-1">
            <Label class="font-mono text-xs">{{ column.name }} ({{ column.data_type }})</Label>
            <Input v-model="insertRowInputs[column.name]" class="font-mono" :placeholder="column.is_nullable ? t('platform.workbench.tenantdb.optional') : t('platform.workbench.tenantdb.required')" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" @click="insertDialogOpen = false">{{ t('common.cancel') }}</Button>
          <Button :disabled="insertRowMutation.isPending.value" @click="submitInsertRow">
            {{ insertRowMutation.isPending.value ? t('platform.workbench.tenantdb.inserting') : t('platform.workbench.tenantdb.insert') }}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>

    <Dialog :open="rowEditDialogOpen" @update:open="rowEditDialogOpen = $event">
      <DialogContent class="sm:max-w-[720px]">
        <DialogHeader>
          <DialogTitle>{{ t('platform.workbench.tenantdb.editRowTitle') }}</DialogTitle>
          <DialogDescription>
            {{ t('platform.workbench.tenantdb.rowId') }}: <span class="font-mono">{{ editingRow ? String(editingRow.id ?? '') : '-' }}</span>
          </DialogDescription>
        </DialogHeader>
        <div class="grid gap-2 md:grid-cols-2">
          <div v-for="column in editableColumns" :key="column.uuid" class="space-y-1">
            <Label class="font-mono text-xs">{{ column.name }} ({{ column.data_type }})</Label>
            <Input v-model="editRowInputs[column.name]" class="font-mono" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" @click="rowEditDialogOpen = false">{{ t('common.cancel') }}</Button>
          <Button :disabled="updateRowMutation.isPending.value" @click="submitEditRow">
            {{ updateRowMutation.isPending.value ? t('platform.workbench.tenantdb.updating') : t('platform.workbench.tenantdb.update') }}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>

    <Dialog :open="rowDeleteDialogOpen" @update:open="rowDeleteDialogOpen = $event">
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{{ t('platform.workbench.tenantdb.deleteRow') }}</DialogTitle>
          <DialogDescription>
            {{ t('platform.workbench.tenantdb.deleteRowDescription', { id: deleteRowTargetId }) }}
          </DialogDescription>
        </DialogHeader>
        <Input v-model="deleteRowConfirmInput" class="font-mono" :placeholder="t('platform.workbench.tenantdb.rowIdPlaceholder')" />
        <DialogFooter>
          <Button variant="outline" @click="rowDeleteDialogOpen = false">{{ t('common.cancel') }}</Button>
          <Button variant="destructive" :disabled="deleteRowMutation.isPending.value" @click="submitDeleteRow">
            {{ deleteRowMutation.isPending.value ? t('platform.workbench.tenantdb.deleting') : t('platform.workbench.tenantdb.deleteRow') }}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  </TenantDbWorkbenchScaffold>
</template>
