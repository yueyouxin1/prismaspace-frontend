<script setup lang="ts">
import type { HTMLAttributes } from 'vue'
import { cn } from '@prismaspace/ui-shadcn/lib/utils'

interface Props extends /* @vue-ignore */ HTMLAttributes {
  class?: HTMLAttributes['class']
}

const props = defineProps<Props>()
</script>

<template>
  <span :class="cn('font-medium text-sm', props.class)" v-bind="$attrs">
    <slot />
  </span>
</template>
