<script setup lang="ts">
import type { HTMLAttributes } from 'vue'
import { cn } from '@prismaspace/ui-shadcn/lib/utils'

interface Props extends /* @vue-ignore */ HTMLAttributes {
  class?: HTMLAttributes['class']
}

const props = defineProps<Props>()
</script>

<template>
  <div
    :class="cn('flex min-w-0 items-center gap-2', props.class)"
    v-bind="$attrs"
  >
    <slot />
  </div>
</template>
