# @prismaspace/workflow

Workflow 资源公开包。

## 公开入口

- `@prismaspace/workflow`
  - workflow graph/render/base 能力 + 主入口 `WorkflowWorkbench`
- `@prismaspace/workflow/main`
  - `WorkflowWorkbench`
- `@prismaspace/workflow/workbench`
  - `WorkflowWorkbench`
- `@prismaspace/workflow/runtime`
  - 当前映射到 workflow 核心导出
- `@prismaspace/workflow/types`
  - workflow 类型入口

## 当前能力

- 工作流节点注册与渲染
- graph 工具与默认值
- runtime mock
- `WorkflowWorkbench`
- `WorkflowWorkbenchScaffold`

## playground

当前仓内仍保留 workflow playground，用于第一方 demo：

- `@prismaspace/workflow-playground/editor/WorkflowStudio.vue`
- `@prismaspace/workflow-playground/form-extensions`

