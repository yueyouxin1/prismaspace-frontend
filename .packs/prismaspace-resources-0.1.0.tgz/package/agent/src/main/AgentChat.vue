<script setup lang="ts">
import { MessageSquareDashed } from 'lucide-vue-next'
import { Card, CardContent, CardHeader, CardTitle } from '@prismaspace/ui-shadcn/components/ui/card'
</script>

<template>
  <Card class="flex min-h-[280px] w-full items-center justify-center border-dashed bg-muted/20">
    <div class="flex flex-col items-center justify-center gap-3 px-6 py-10 text-center">
      <MessageSquareDashed class="size-10 text-muted-foreground" />
      <div class="space-y-1">
        <CardTitle class="text-base">AgentChat</CardTitle>
        <CardContent class="p-0 text-sm text-muted-foreground">
          Public production component placeholder. The final chat runtime will be implemented here.
        </CardContent>
      </div>
    </div>
  </Card>
</template>
