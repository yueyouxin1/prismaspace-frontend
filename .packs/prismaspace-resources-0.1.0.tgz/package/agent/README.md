# @prismaspace/agent

Agent 资源公开包。

## 公开入口

- `@prismaspace/agent`
  - 主入口：`AgentChat`
- `@prismaspace/agent/main`
  - `AgentChat`
- `@prismaspace/agent/workbench`
  - `AgentWorkbench` / `AgentIdeWorkbench`
- `@prismaspace/agent/runtime`
  - Agent 运行态相关类型
- `@prismaspace/agent/types`
  - Agent 公共类型

## 当前能力

- `AgentChat`
  - 包主入口，占位中的生产级聊天组件
- `AgentWorkbench`
  - 完整 Agent 工作台公开入口
- `AgentIdeWorkbench`
  - Agent IDE 视图组件
- `AgentWorkbenchScaffold`
  - Agent 工作台基础壳

## 宿主接入

工作台应通过统一 client 挂载，不依赖宿主私有 store/context。
